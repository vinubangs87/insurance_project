
<?php $__env->startSection('content'); ?>

<!-- This is a common form used for all Master menu  -->
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
				<h3>Vehicle list</h3>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row">
		<div class="col-md-12 col-sm-12 ">
							<?php if(session()->has('message')): ?>            
			            <div class='alert alert-success'>
			                 <button class='close' data-dismiss='alert'>×</button>
			                 <strong><?php echo e(session()->get('message')); ?> </strong>
			            </div>
			        <?php endif; ?>
                <div class="x_panel">
                  <div class="x_title">
                    <h2>View records: </h2>
                    <div class="clearfix"></div>
                  
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                          	<select id="search2" name="expense_category" class="form-control form-control-sm m-2">
                  	          <option value="none">Select a Status</option>
                  	          <option value="active">Active</option>
                  	          <option value="inactive">Inactive</option>
                  	        </select>
                            <div class="card-box table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th>Customer name</th>
                          <th>Customer mobile</th>
                          <th>Vehicle number</th>
                          <th>Registration number</th>
                          <th>Policy number</th>
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      	<?php $__currentLoopData = $vehiclelist; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vehiclelist): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($vehiclelist->customer_name); ?></td>
                          <td><?php echo e($vehiclelist->customer_mobile); ?></td>
                          <td><?php echo e($vehiclelist->vehicle_number); ?></td>
                          <td><?php echo e($vehiclelist->registration_number); ?></td>
                          <td><?php echo e($vehiclelist->policy_number); ?></td>
                          
                          	<?php if((\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->insurance_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->fitness_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->mv_tax_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->pucc_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->permit_valid_upto_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehiclelist->policy_end_date)): ?>
                          	<td class="red inactive-class"><div class="status-inactive">Inactive</div></td>
                          	<?php else: ?>
	                          <td class="green"><div class="status-active" title="Active">Active</div></td>
	                          <?php endif; ?>
                          
                          <td><form method="POST" action="<?php echo e(route('vehicledetails.destroy', $vehiclelist->id)); ?>">
                              <?php echo csrf_field(); ?>
                              <input name="_method" type="hidden" value="DELETE">
                              <button type="submit" class="btn btn-danger btn-sm delete" title='Delete'>Delete</button>
                          </form>

                          <a href="<?php echo e(route('vehicledetails.edit', $vehiclelist->id)); ?>" class="btn btn-primary btn-sm">Edit</a> <a href="<?php echo e(route('vehicledetails.show', $vehiclelist->id)); ?>"  class="btn btn-primary btn-sm">View</a></td>
                        </tr>
                      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>

		</div>
	</div>
</div>        
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pagespecificjs'); ?>

<script type="text/javascript">
    $(document).ready(function() {
        $('.delete').click(function(e) {
            if(!confirm('Are you sure you want to delete this record?')) {
                e.preventDefault();
            }
        });
    });
</script>

<script>
$(function() {
  $('input[name="daterange"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'));
  });
});
</script>

<script type="text/javascript">
$(document).ready(function() {
  var DT1 = $('#datatable').DataTable({
  	"bDestroy": true,
    retrieve: true,
    columnDefs: [{
      orderable: true,
      className: 'select-checkbox',
      targets: 0,
    }],
    select: {
      style: 'os',
      selector: 'td:first-child'
    },
    order: [
      [1, 'asc']
    ],
    dom: 'lrt'
  });
  $(".selectAll").on("click", function(e) {
    if ($(this).is(":checked")) {
      DT1.rows().select();
    } else {
      DT1.rows().deselect();
    }
  });

  $('#search').on('input', () => {
    DT1.search($('#search').val()).draw();
  });
  $('#search2').on('change', () => {
    const state = $("#search2").val();
    if (state === "none") {
      $(".status-active").parent().parent().attr("hidden", false);
      $(".status-inactive").parent().parent().attr("hidden", false);
      return;
    }

    $(".status-" + ((state === "active") ? 'inactive' : 'active')).parent().parent().attr("hidden", true);
    $(".status-" + state).parent().parent().attr("hidden", false);

  });
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/vehicleDetails/vehicleList.blade.php ENDPATH**/ ?>