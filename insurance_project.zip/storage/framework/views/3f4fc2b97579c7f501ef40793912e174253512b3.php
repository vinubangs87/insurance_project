
<?php $__env->startSection('content'); ?>

<?php echo $__env->make('admin.commonForm.routenames', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- This is a common form used for all Master menu  -->
<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
				<h3><?php echo e($title); ?></h3>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row">
			<div class="col-md-12 col-sm-12 ">

				<?php if(session()->has('message')): ?>            
            <div class='alert alert-success'>
                 <button class='close' data-dismiss='alert'>×</button>
                 <strong><?php echo e(session()->get('message')); ?> </strong>
            </div>
        <?php endif; ?>
        <?php if(session()->has('warning')): ?>            
            <div class='alert alert-danger'>
                 <button class='close' data-dismiss='alert'>×</button>
                 <strong><?php echo e(session()->get('warning')); ?> </strong>
            </div>
        <?php endif; ?>

				<?php if(isset($dataforshow)): ?>
				<!-- Start form fill -->
				<div class="x_panel">
					<div class="x_title">
						<h2><?php echo e($formtype); ?> <small style="color:red;">(* Means mandatory field)</small></h2>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<br />						
						<form  action="<?php echo e(route(routeName)); ?>" method="post" data-parsley-validate class="form-horizontal form-label-left">
							<?php echo csrf_field(); ?>

							<?php if(isset($producttype)): ?> 
							<div class="item form-group">
								<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Product type <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 ">
									<select id="producttypes_id" class="form-control" name="producttypes_id">
										<option value="">Choose..</option>
										<?php $__currentLoopData = $producttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($producttype->id); ?>"><?php echo e($producttype->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<small class="text-danger">
                    <?php echo e($errors->first('producttypes_id',':message')); ?>

                  </small>
								</div>
							</div>
							<?php endif; ?>

							

							<div class="item form-group">
								<label class="col-form-label col-md-3 col-sm-3 label-align" for="title"><?php echo e($inputName); ?> <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 ">
									<input type="text" id="title" class="form-control" name="title" value="<?php echo e(old('title')); ?>">
									<small class="text-danger">
		                              <?php echo e($errors->first('title',':message')); ?>

		                            </small>
								</div>
							</div>
							<div class="item form-group">
								<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Status <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 ">
									<select id="heard" class="form-control" name="status">
										<option value="">Choose..</option>
										<option value="1">Active</option>
										<option value="0">Inactive</option>
									</select>
									<small class="text-danger">
		                              <?php echo e($errors->first('status',':message')); ?>

		                            </small>
								</div>
							</div>
							<div class="ln_solid"></div>
							<div class="item form-group">
								<div class="col-md-6 col-sm-6 offset-md-3">
									<button type="submit" class="btn btn-success">Submit</button>
								</div>
							</div>

						</form>
					</div>
				</div>
				<!-- End form fill -->
				<?php endif; ?>


				<?php if(isset($dataforedit)): ?>
				<!-- Start form fill -->
				<div class="x_panel">
					<div class="x_title">
						<h2><?php echo e($formtype); ?> <small style="color:red;">(* Means mandatory field)</small></h2>
						<div class="clearfix"></div>
					</div>
					<div class="x_content">
						<br />						
						<form  action="<?php echo e(route(routeName, $dataforedit->id)); ?>" method="post" data-parsley-validate class="form-horizontal form-label-left">
							<?php echo csrf_field(); ?>
							<?php echo e(method_field('PUT')); ?>


							<?php if(isset($producttype)): ?> 
							<div class="item form-group">
								<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Product type <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 ">
									<select id="producttypes_id" class="form-control" name="producttypes_id">
										<option value="">Choose..</option>
										<?php $__currentLoopData = $producttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<option value="<?php echo e($producttype->id); ?>" <?php echo e($producttype->id == $dataforedit->producttypes_id ? 'selected' : ''); ?>><?php echo e($producttype->title); ?></option>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</select>
									<small class="text-danger">
                    <?php echo e($errors->first('producttypes_id',':message')); ?>

                  </small>
								</div>
							</div>
							<?php endif; ?>

							

							<div class="item form-group">
								<label class="col-form-label col-md-3 col-sm-3 label-align" for="title"><?php echo e($inputName); ?> <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 ">
									<input type="text" id="title" class="form-control" name="title" value="<?php echo e($dataforedit->title); ?>">
									<small class="text-danger">
		                              <?php echo e($errors->first('title',':message')); ?>

		                            </small>
								</div>
							</div>
							<div class="item form-group">
								<label class="col-form-label col-md-3 col-sm-3 label-align" for="last-name">Status <span class="required">*</span>
								</label>
								<div class="col-md-6 col-sm-6 ">
									<select id="heard" class="form-control" name="status">
										<option value="">Choose..</option>
										<option value="1" <?php echo e($dataforedit->status == 1 ? 'selected' : ''); ?>>Active</option>
										<option value="0" <?php echo e($dataforedit->status == 0 ? 'selected' : ''); ?>>Inactive</option>
									</select>
									<small class="text-danger">
		                              <?php echo e($errors->first('status',':message')); ?>

		                            </small>
								</div>
							</div>
							<div class="ln_solid"></div>
							<div class="item form-group">
								<div class="col-md-6 col-sm-6 offset-md-3">
									<button type="submit" class="btn btn-success">Update</button>
									<a href="<?php echo e(route(routeCancel)); ?>" class="btn btn-success">Cancel</a>
								</div>
							</div>

						</form>
					</div>
				</div>
				<!-- End form fill -->
				<?php endif; ?>


			</div>

			<?php if(isset($dataforshow)): ?>
		<div class="col-md-12 col-sm-12 ">
                <div class="x_panel">
                  <div class="x_title">
                    <h2>View records</h2>
                    <div class="clearfix"></div>
                  </div>
                  <div class="x_content">
                      <div class="row">
                          <div class="col-sm-12">
                            <div class="card-box table-responsive">
                    <table id="datatable" class="table table-striped table-bordered" style="width:100%">
                      <thead>
                        <tr>
                          <th><?php echo e($inputName); ?></th>
  <?php if(isset($producttype)): ?><th>Product type</th><?php endif; ?> 
    
                          <th>Status</th>
                          <th>Action</th>
                        </tr>
                      </thead>


                      <tbody>
                      	<?php $__currentLoopData = $dataforshow; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataforshow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($dataforshow->title); ?></td>
  <?php if(isset($producttype)): ?><td><?php echo e($dataforshow->prducttype_name); ?></td><?php endif; ?> 
   
                          <td><?php echo e(($dataforshow->status == 1) ? 'Active' : 'Inactive'); ?></td>
                          <td><a href="<?php echo e(route(routeNameEdit, $dataforshow->id)); ?>">Edit</a></td>
                        </tr>
                      	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                    </table>
                  </div>
                  </div>
              </div>
            </div>
                </div>
              </div>
         <?php endif; ?>

		</div>
	</div>
</div>        
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pagespecificjs'); ?>
<script type="text/javascript">
	$(document).ready(function () {
  $('#datatable').DataTable();
  $('.dataTables_length').addClass('bs-select');
});
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/commonForm/commonForm.blade.php ENDPATH**/ ?>