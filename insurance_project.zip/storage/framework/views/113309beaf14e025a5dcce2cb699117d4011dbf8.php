<script type="text/javascript">
	
// Show broker name dependent field based on insurance company
$('#insuranceCompany_id').on('change', function() {
	var insuranceCompany_id = $(this).val();
	$.ajax({
	url: "<?php echo e(route('dependent.brokerName')); ?>",
	type: "POST",
	data: {
	    insuranceCompany_id: insuranceCompany_id,
	    _token: '<?php echo e(csrf_token()); ?>'
	},
	dataType: "json",
	success:function(data) {
		$('#broker_id').empty();
			$('#broker_id').append('<option value="">Select any one</option>');
		if(data.status == 'success'){
	    $.each(data.data, function(key, value) {
	        $('#broker_id').append('<option value="'+key+'">'+value+'</option>');
	    });
		}
	}
	});
});
</script><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/vehicleDetails/brokerdetailsJs.blade.php ENDPATH**/ ?>