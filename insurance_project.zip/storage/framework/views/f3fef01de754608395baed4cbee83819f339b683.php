
<?php $__env->startSection('content'); ?>
<div id="banner-area" class="banner-area" style="background-color: #1A2229">
  <div class="banner-text">
    <div class="container">
        <div class="row">
          <div class="col-lg-12">
              <div class="banner-heading">
                <h1 class="banner-title">Sevices</h1>
                
              </div>
          </div><!-- Col end -->
        </div><!-- Row end -->
    </div><!-- Container end -->
  </div><!-- Banner text end -->
</div><!-- Banner area end --> 
<section id="main-container" class="main-container">
  <div class="container">

    <div class="row">
     <div class="col-lg-12 text-center">
          <img loading="lazy" class="img-fluid" src="<?php echo e(asset("frontend/images/slider-main/banner1.jpeg")); ?>" alt="Durga insurance solutions">
        </div><!-- Col end -->
    </div><!-- Row end -->

  </div><!-- Conatiner end -->
</section><!-- Main container end -->

        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.frontendapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/services.blade.php ENDPATH**/ ?>