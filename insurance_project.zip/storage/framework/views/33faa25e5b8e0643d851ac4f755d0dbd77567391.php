
<?php $__env->startSection('content'); ?>

<div class="right_col" role="main">
          <!-- top tiles -->
          
          <!-- /top tiles -->
        </div>
        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/home.blade.php ENDPATH**/ ?>