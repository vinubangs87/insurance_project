
<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
				<h3>Vehicle details</h3>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row">
		              <div class="col-md-12">
		                <div class="x_panel">
		                  <div class="x_title">
		                    <h2>RC Status</h2>
		                    
		                    <div class="clearfix"></div>
		                  </div>
		                  <div class="x_content">

		                    <section class="content invoice">
		                      <!-- info row -->
		                      <div class="row invoice-info">
		                        <div class="col-sm-4 invoice-col">
		                          <b>Owner detail: </b>
		                          <address>
                                      <strong>Name: </strong><?php echo e($vehicledetail->customer_name); ?>

                                      <br/>
                                      <strong>Mobile: </strong><?php echo e($vehicledetail->customer_mobile); ?>

                                      <br/>
                                      <strong>Email: </strong><?php echo e($vehicledetail->customer_email); ?>

                                      <br/>
                                      <strong>Address: </strong>
                                      <br/>
                                      <?php echo e($vehicledetail->customer_address); ?>

                                  </address>
		                        </div>
		                        <!-- /.col -->
		                        <div class="col-sm-4 invoice-col">
		                          <b> Vehicle detail: </b>
		                          <address>
                                      <strong>Vehicle number: </strong><?php echo e($vehicledetail->vehicle_number); ?>

                                      <br/>
                                      <strong>Registration number: </strong><?php echo e($vehicledetail->registration_number); ?>

                                      <br/>
                                      <strong>Product type: </strong><?php echo e($vehicledetail->pt_title); ?>

                                      <br/>
                                      <strong>Product name: </strong><?php echo e($vehicledetail->pn_title); ?>

                                      <br/>
                                      <strong>Engine type: </strong><?php echo e($vehicledetail->et_title); ?>

                                      <br/>
                                      <strong>Permit type: </strong><?php echo e($vehicledetail->pert_title); ?>

                                      <br/>
                                      <strong>Insurance company: </strong><?php echo e($vehicledetail->ic_title); ?>

                                      <br/>
                                  </address>
		                        </div>
		                        <!-- /.col -->
		                        <div class="col-sm-4 invoice-col">
		                          <b>Status:</b>
		                          <?php if((\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->insurance_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->fitness_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->mv_tax_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->pucc_expiry_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->permit_valid_upto_date) || (\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->policy_end_date)): ?>
		                          <b class="red inactive-class">Inactive</b>
		                          <?php else: ?>
		                          <b class="blue">Active</b>
		                          <?php endif; ?>
		                          <br>
		                          
		                          <br>
		                          <b>Registration date:</b> <?php echo e(\Carbon\Carbon::parse($vehicledetail->registration_date)->format('d/m/Y')); ?> <br>
		                          <b>Registration Expiry date:</b> <span  class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->expiry_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->expiry_date)->format('d/m/Y')); ?></span> <br>
		                          <b>Uploaded RC:</b> 
		                          <?php if($vehicledetail->rc_image): ?>
							        <a class="blue" href="<?php echo e(route('file.view',['filename' => $vehicledetail->rc_image,'directory' => 'file_rc_image'])); ?>" target="_BLANK">Check uploaded file</a>
								    <?php else: ?>
								        <span style="color:purple">No file uploaded</span>
								    <?php endif; ?> <br>
		                          <b>Engine number:</b> <?php echo e($vehicledetail->engine_number); ?>

		                          <br>
		                          <b>chasis_number:</b> <?php echo e($vehicledetail->chasis_number); ?>                                  
                                  <br/>
                                  <strong>Renewal premium: </strong><?php echo e($vehicledetail->renewal_premium); ?>

		                        </div>
		                        <!-- /.col -->
		                      </div>
		                      <hr/>
		                      <!-- /.row -->
		                      <div class="row">
		                        <!-- /.col -->
		                        <div class="col-md-6">
		                          <p class="lead">Insurance Details:</p>
		                          <div class="table-responsive">
		                            <table class="table">
		                              <tbody>
		                                <tr>
		                                  <th>Insurance start date:</th>
		                                  <td><?php echo e(\Carbon\Carbon::parse($vehicledetail->insurance_start_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>Insurance expiry date:</th>
		                                  <td class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->insurance_expiry_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->insurance_expiry_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>Previous insurance file:</th>
		                                  <td>
		                                  <?php if($vehicledetail->previous_insurance_file): ?>
											<a class="blue" href="<?php echo e(route('file.view',['filename' => $vehicledetail->previous_insurance_file,'directory' => 'previous_insurance_file'])); ?>" target="_BLANK">(Check uploaded file)</a>
											<?php else: ?>
											<span style="color:purple">(No previous file uploaded)</span>
											<?php endif; ?>
											</td>

		                                </tr>
		                                <tr>
		                                  <th>New insurance file:</th>
		                                  <td>
		                                  <?php if($vehicledetail->new_insurance_file): ?>
											<a class="blue" href="<?php echo e(route('file.view',['filename' => $vehicledetail->new_insurance_file,'directory' => 'new_insurance_file'])); ?>" target="_BLANK">(Check uploaded file)</a>
											<?php else: ?>
											<span style="color:purple">(No previous file uploaded)</span>
											<?php endif; ?>
											</td>
		                                </tr>
		                              </tbody>
		                            </table>
		                          </div>
		                        </div>
		                        <div class="col-md-6">
		                          <p class="lead">Permit/Validity Details:</p>
		                          <div class="table-responsive">
		                            <table class="table">
		                              <tbody>
		                                <tr>
		                                  <th>Permit number:</th>
		                                  <td><?php echo e($vehicledetail->permit_number); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>Permit valid upto: </th>
		                                  <td class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->permit_valid_upto_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->permit_valid_upto_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>Fitness expiry date:</th>
		                                  <td class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->fitness_expiry_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->fitness_expiry_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>MV tax expiry date: </th>
		                                  <td class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->mv_tax_expiry_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->mv_tax_expiry_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>PUCC expiry date:</th>
		                                  <td class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->pucc_expiry_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->pucc_expiry_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                              </tbody>
		                            </table>
		                          </div>
		                        </div>

		                        <div class="col-md-6">
		                          <p class="lead">Finance Details:</p>
		                          <div class="table-responsive">
		                            <table class="table">
		                              <tbody>
		                                <tr>
		                                  <th>Finance:</th>
		                                  <td><?php echo e($vehicledetail->finance_type == 1 ? 'Yes' : 'No'); ?></td>
		                                </tr>
		                                <?php if($vehicledetail->finance_type == 1): ?>
		                                <tr>
		                                  <th>Finance company: </th>
		                                  <td><?php echo e($vehicledetail->fc_title); ?></td>
		                                </tr>
		                                <?php endif; ?>
		                              </tbody>
		                            </table>
		                          </div>
		                        </div>

		                         <div class="col-md-6">
		                          <p class="lead">Policy Details:</p>
		                          <div class="table-responsive">
		                            <table class="table">
		                              <tbody>
		                                <tr>
		                                  <th>Policy number: </th>
		                                  <td><?php echo e($vehicledetail->policy_number); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>Policy start date: </th>
		                                  <td><?php echo e(\Carbon\Carbon::parse($vehicledetail->policy_start_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                                <tr>
		                                  <th>Policy end date: </th>
		                                  <td class="<?php echo e(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->policy_end_date ? 'red': 'blue'); ?>"><?php echo e(\Carbon\Carbon::parse($vehicledetail->policy_end_date)->format('d/m/Y')); ?></td>
		                                </tr>
		                              </tbody>
		                            </table>
		                          </div>
		                        </div>
		                        <!-- /.col -->
		                      </div>
		                      <hr/>
		                      <!-- /.row -->

		                      <!-- this row will not appear when printing -->
		                      <div class="row no-print">
		                        <div class=" ">
		                         
		                         <a href="<?php echo e(route('vehicledetails.edit', $vehicledetail->id)); ?>" class="btn btn-primary">Update this customer</a>
		                        </div>
		                      </div>
		                    </section>
		                  </div>
		                </div>
		              </div>
		            </div>
	</div>
</div>        
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/vehicleDetails/vehicledetails.blade.php ENDPATH**/ ?>