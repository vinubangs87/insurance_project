
<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
				<h3>Vehicle update detail form</h3>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row">
						<div class="col-md-12 ">
							<?php if(session()->has('message')): ?>            
			            <div class='alert alert-success'>
			                 <button class='close' data-dismiss='alert'>×</button>
			                 <strong><?php echo e(session()->get('message')); ?> </strong>
			            </div>
			        <?php endif; ?>
							<div class="x_panel">
								<div class="x_title">
									<h2>Please update the details <small style="color:red;">(* Means mandatory field)</small></h2>									
									<div class="clearfix"></div>
								</div>
									<form class="form-label-left" action="<?php echo e(route('vehicledetails.update', $vehicledetail->id)); ?>" method="post" enctype='multipart/form-data'>
										<?php echo csrf_field(); ?>
										<?php echo e(method_field('PUT')); ?>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Insurance company <span class="required">*</span></label>
											<select id="insuranceCompany_id" class="form-control" name="insuranceCompany_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $insurancecompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurancecompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($insurancecompany->id); ?>" <?php echo e($vehicledetail->insuranceCompany_id == $insurancecompany->id ? 'selected' : ''); ?>><?php echo e($insurancecompany->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('insuranceCompany_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Product type <span class="required">*</span></label>
											<select id="producttype_id" class="form-control" name="producttype_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $producttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($producttype->id); ?>" <?php echo e($vehicledetail->producttype_id == $producttype->id ? 'selected' : ''); ?>><?php echo e($producttype->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('producttype_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Product name <span class="required">*</span></label>
											<select id="procuctname_id" class="form-control" name="procuctname_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $procuctname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procuctname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($procuctname->id); ?>" <?php echo e($vehicledetail->procuctname_id == $procuctname->id ? 'selected' : ''); ?>><?php echo e($procuctname->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('procuctname_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Engine type <span class="required">*</span></label>
											<select id="enginetype_id" class="form-control" name="enginetype_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $enginetype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enginetype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($enginetype->id); ?>" <?php echo e($vehicledetail->enginetype_id == $enginetype->id ? 'selected' : ''); ?>><?php echo e($enginetype->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('enginetype_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Permit type <span class="required">*</span></label>
											<select id="permittype_id" class="form-control" name="permittype_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $permittype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permittype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($permittype->id); ?>" <?php echo e($vehicledetail->permittype_id == $permittype->id ? 'selected' : ''); ?>><?php echo e($permittype->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('permittype_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Customer name <span class="required">*</span></label>
											<input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo e($vehicledetail->customer_name); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_name',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Customer mobile <span class="required">*</span></label>
											<input type="text" class="form-control" id="customer_mobile" name="customer_mobile" maxlength="10" pattern="[1-9]{1}[0-9]{9}" value="<?php echo e($vehicledetail->customer_mobile); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_mobile',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Customer email</label>
											<input type="text" class="form-control" id="customer_email" name="customer_email" value="<?php echo e($vehicledetail->customer_email); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_email',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-12 col-sm-12  form-group has-feedback">
											<label for="inputSuccess2">Customer address <span class="required">*</span></label>
											<textarea class="form-control" id="customer_address" name="customer_address"><?php echo e($vehicledetail->customer_address); ?></textarea>
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_address',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Vehicle/Registration number <span class="required">*</span></label>
											<input type="text" class="form-control" id="vehicle_number" name="vehicle_number" value="<?php echo e($vehicledetail->vehicle_number); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('vehicle_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Upload RC 
												<?php if($vehicledetail->rc_image): ?>
												<a class="blue" href="<?php echo e(route('file.view',['filename' => $vehicledetail->rc_image,'directory' => 'file_rc_image'])); ?>" target="_BLANK">(Check uploaded file)</a>
												<?php else: ?>
												<span class="blue">(No previous file uploaded)</span>
												<?php endif; ?>
											</label>
											<input type="file" class="form-control" id="rc_image" name="rc_image" />
											<small class="text-danger">
		                    <?php echo e($errors->first('rc_image',':message')); ?>

		                  </small>
										</div>

										

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Registration date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="registration_date" name="registration_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->registration_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('registration_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Registration Expiry date <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->expiry_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="expiry_date" name="expiry_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->expiry_date)->format('d/m/Y')); ?>" placeholder="MM/DD/YYYY" />
											<small class="text-danger">
		                    <?php echo e($errors->first('expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Insurance start date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="insurance_start_date" name="insurance_start_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->insurance_start_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('insurance_start_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Insurance expiry date <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->insurance_expiry_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="insurance_expiry_date" name="insurance_expiry_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->insurance_expiry_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('insurance_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">Previous insurance file 
												<?php if($vehicledetail->previous_insurance_file): ?>
												<a class="blue" href="<?php echo e(route('file.view',['filename' => $vehicledetail->previous_insurance_file,'directory' => 'previous_insurance_file'])); ?>" target="_BLANK">(Check uploaded file)</a>
												<?php else: ?>
												<span class="blue">(No previous file uploaded)</span>
												<?php endif; ?>

											</label>
											<input type="file" class="form-control" id="previous_insurance_file" name="previous_insurance_file" />
											<small class="text-danger">
		                    <?php echo e($errors->first('previous_insurance_file',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-3 col-sm-3  form-group has-feedback">
											<label for="inputSuccess2">New insurance file 
												<?php if($vehicledetail->new_insurance_file): ?>
												<a class="blue" href="<?php echo e(route('file.view',['filename' => $vehicledetail->new_insurance_file,'directory' => 'new_insurance_file'])); ?>" target="_BLANK">(Check uploaded file)</a>
												<?php else: ?>
												<span class="blue">(No previous file uploaded)</span>
												<?php endif; ?>
											</label>
											<input type="file" class="form-control" id="new_insurance_file" name="new_insurance_file" />
											<small class="text-danger">
		                    <?php echo e($errors->first('new_insurance_file',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Fitness expiry date <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->fitness_expiry_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="fitness_expiry_date" name="fitness_expiry_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->fitness_expiry_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('fitness_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">MV tax expiry date <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->mv_tax_expiry_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="mv_tax_expiry_date" name="mv_tax_expiry_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->mv_tax_expiry_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('mv_tax_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">PUCC expiry date <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->pucc_expiry_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="pucc_expiry_date" name="pucc_expiry_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->pucc_expiry_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('pucc_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Finance <span class="required">*</span></label>
											<select id="finance_type" class="form-control" name="finance_type">
												<option value="">Choose..</option>
												<option value="1" <?php echo e($vehicledetail->finance_type == 1 ? 'selected' : ''); ?>>Yes</option>
												<option value="0" <?php echo e($vehicledetail->finance_type == 0 ? 'selected' : ''); ?>>no</option>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('finance_type',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback" id="financecompany_div" style="display: none;">
											<label for="inputSuccess2">Finance company <span class="required">*</span></label>
		                  <select id="financecompany_id" class="form-control" name="financecompany_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $financecompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $financecompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($financecompany->id); ?>" <?php echo e($vehicledetail->financecompany_id == $financecompany->id ? 'selected' : ''); ?>><?php echo e($financecompany->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('financecompany_id',':message')); ?>

		                  </small>

										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Permit number <span class="required">*</span></label>
											<input type="text" class="form-control" id="permit_number" name="permit_number" value="<?php echo e($vehicledetail->permit_number); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('permit_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Permit valid upto <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->permit_valid_upto_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="permit_valid_upto_date" name="permit_valid_upto_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->permit_valid_upto_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('permit_valid_upto_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Policy number <span class="required">*</span></label>
											<input type="text" class="form-control" id="policy_number" name="policy_number" value="<?php echo e($vehicledetail->policy_number); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('policy_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Policy start date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="policy_start_date" name="policy_start_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->policy_start_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('policy_start_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Policy end date <span class="required">*</span>
												<?php if(\Carbon\Carbon::now()->format('Y-m-d') > $vehicledetail->policy_end_date): ?> 
													<b class=" red inactive-class">(Inactive)</b>
												<?php else: ?>
													<b class="blue">(Active)</b>
												<?php endif; ?>
											</label>
											<input type="text" class="form-control datetype" id="policy_end_date" name="policy_end_date" value="<?php echo e(\Carbon\Carbon::parse($vehicledetail->policy_end_date)->format('d/m/Y')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('policy_end_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Renewal premium</label>
											<input type="text" class="form-control" id="renewal_premium" name="renewal_premium" value="<?php echo e($vehicledetail->renewal_premium); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('renewal_premium',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Engine number</label>
											<input type="text" class="form-control" id="engine_number" name="engine_number" value="<?php echo e($vehicledetail->engine_number); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('engine_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Chasis number</label>
											<input type="text" class="form-control" id="chasis_number" name="chasis_number" value="<?php echo e($vehicledetail->chasis_number); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('chasis_number',':message')); ?>

		                  </small>
										</div>

										<div class="ln_solid"></div>
											<div class="col-md-12 col-sm-12  offset-md-3">
												<button type="submit" class="btn btn-success">Update</button>
												<a href="<?php echo e(route('vehicledetails.show', $vehicledetail->id)); ?>" class="btn btn-primary">View this customer</a>
											</div>

									</form>
							</div>

						</div>

					</div>
	</div>
</div>        
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pagespecificjs'); ?>
<script>
$(document).ready(function(){
    $('#finance_type').on('change', function(){
		var finance_type = $(this).val(); 
		if(finance_type== 1)
		{
        $("#financecompany_div").show();
      	}
      	else
      	{
        $("#financecompany_div").hide();
      	}
    });

    var f_val = $( "#finance_type option:selected" ).val();
		if(f_val== 1)
		{
        $("#financecompany_div").show();
      	}
      	else
      	{
        $("#financecompany_div").hide();
      	}
});
</script>
<?php echo $__env->make('admin.vehicleDetails.vehicledetailsJs', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> 
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/vehicleDetails/updatedetails.blade.php ENDPATH**/ ?>