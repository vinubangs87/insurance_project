<p>Name: <?php echo e($data['name']); ?></p>
<p>Hi, This is <?php echo e($data['email']); ?></p>
<p>Hi, This is <?php echo e($data['subject']); ?></p>
<p>I have some query like <?php echo e($data['message']); ?>.</p><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/contact_form_mail_content.blade.php ENDPATH**/ ?>