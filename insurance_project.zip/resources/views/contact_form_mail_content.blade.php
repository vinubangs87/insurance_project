<p><b>Name:</b> {{ $data['name'] }}</p>
<p><b>Email:</b> {{ $data['email'] }}</p>
<p><b>Subject:</b> {{ $data['subject'] }}</p>
<p><b>Message:</b> {{ $data['message'] }}.</p>