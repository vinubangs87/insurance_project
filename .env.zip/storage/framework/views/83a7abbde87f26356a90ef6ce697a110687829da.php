
<?php $__env->startSection('content'); ?>

<!-- page content -->
<div class="right_col" role="main">
	<div class="">
		<div class="page-title">
			<div class="title_left">
				<h3>Vehicle detail form</h3>
			</div>
		</div>
		<div class="clearfix"></div>
		<div class="row">
						<div class="col-md-12 ">
							<?php if(session()->has('message')): ?>            
			            <div class='alert alert-success'>
			                 <button class='close' data-dismiss='alert'>×</button>
			                 <strong><?php echo e(session()->get('message')); ?> </strong>
			            </div>
			        <?php endif; ?>
							<div class="x_panel">
								<div class="x_title">
									<h2>Please fill the form <small style="color:red;">(* Means mandatory field)</small></h2>									
									<div class="clearfix"></div>
								</div>
									<form class="form-label-left" action="<?php echo e(route('vehicledetails.store')); ?>" method="post">
										<?php echo csrf_field(); ?>
										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Insurance company <span class="required">*</span></label>
											<select id="insuranceCompany_id" class="form-control" name="insuranceCompany_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $insurancecompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $insurancecompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($insurancecompany->id); ?>" <?php echo e(old('insuranceCompany_id') == $insurancecompany->id ? 'selected' : ''); ?>><?php echo e($insurancecompany->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('insuranceCompany_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Product type <span class="required">*</span></label>
											<select id="producttype_id" class="form-control" name="producttype_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $producttype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $producttype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($producttype->id); ?>" <?php echo e(old('producttype_id') == $producttype->id ? 'selected' : ''); ?>><?php echo e($producttype->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('producttype_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Product name <span class="required">*</span></label>
											<select id="procuctname_id" class="form-control" name="procuctname_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $procuctname; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $procuctname): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($procuctname->id); ?>" <?php echo e(old('procuctname_id') == $procuctname->id ? 'selected' : ''); ?>><?php echo e($procuctname->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('procuctname_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Engine type <span class="required">*</span></label>
											<select id="enginetype_id" class="form-control" name="enginetype_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $enginetype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $enginetype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($enginetype->id); ?>" <?php echo e(old('enginetype_id') == $enginetype->id ? 'selected' : ''); ?>><?php echo e($enginetype->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('enginetype_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Permit type <span class="required">*</span></label>
											<select id="permittype_id" class="form-control" name="permittype_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $permittype; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permittype): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($permittype->id); ?>" <?php echo e(old('permittype_id') == $permittype->id ? 'selected' : ''); ?>><?php echo e($permittype->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('permittype_id',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Customer name <span class="required">*</span></label>
											<input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo e(old('customer_name')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_name',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Customer mobile <span class="required">*</span></label>
											<input type="text" class="form-control" id="customer_mobile" name="customer_mobile" value="<?php echo e(old('customer_mobile')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_mobile',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Customer email</label>
											<input type="text" class="form-control" id="customer_email" name="customer_email" value="<?php echo e(old('customer_email')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_email',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-12 col-sm-12  form-group has-feedback">
											<label for="inputSuccess2">Customer address <span class="required">*</span></label>
											<textarea class="form-control" id="customer_address" name="customer_address"><?php echo e(old('customer_address')); ?></textarea>
											<small class="text-danger">
		                    <?php echo e($errors->first('customer_address',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Vehicle number <span class="required">*</span></label>
											<input type="text" class="form-control" id="vehicle_number" name="vehicle_number" value="<?php echo e(old('vehicle_number')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('vehicle_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Registration number <span class="required">*</span></label>
											<input type="text" class="form-control" id="registration_number" name="registration_number" value="<?php echo e(old('registration_number')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('registration_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Registration/Expiry date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="registration_date" name="registration_date" value="<?php echo e(old('registration_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('registration_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback" style="display:none;">
											<label for="inputSuccess2">Registration Expiry date</label>
											<input type="text" class="form-control datetype" id="expiry_date" name="expiry_date" value="<?php echo e(old('expiry_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Insurance expiry date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="insurance_expiry_date" name="insurance_expiry_date" value="<?php echo e(old('insurance_expiry_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('insurance_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Fitness expiry date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="fitness_expiry_date" name="fitness_expiry_date" value="<?php echo e(old('fitness_expiry_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('fitness_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">MV tax expiry date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="mv_tax_expiry_date" name="mv_tax_expiry_date" value="<?php echo e(old('mv_tax_expiry_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('mv_tax_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">PUCC expiry date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="pucc_expiry_date" name="pucc_expiry_date" value="<?php echo e(old('pucc_expiry_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('pucc_expiry_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Finance <span class="required">*</span></label>
											<select id="finance_type" class="form-control" name="finance_type">
												<option value="">Choose..</option>
												<option value="1" <?php echo e(old('finance_type') == 1 ? 'selected' : ''); ?>>Yes</option>
												<option value="0" <?php echo e(old('finance_type') == 0 ? 'selected' : ''); ?>>no</option>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('finance_type',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback" id="financecompany_div" style="display: none;">
											<label for="inputSuccess2">Finance company <span class="required">*</span></label>
		                  <select id="financecompany_id" class="form-control" name="financecompany_id">
												<option value="">Choose..</option>
												<?php $__currentLoopData = $financecompany; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $financecompany): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<option value="<?php echo e($financecompany->id); ?>" <?php echo e(old('financecompany_id') == $financecompany->id ? 'selected' : ''); ?>><?php echo e($financecompany->title); ?></option>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</select>
											<small class="text-danger">
		                    <?php echo e($errors->first('financecompany_id',':message')); ?>

		                  </small>

										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Permit number <span class="required">*</span></label>
											<input type="text" class="form-control" id="permit_number" name="permit_number" value="<?php echo e(old('permit_number')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('permit_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Permit valid upto <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="permit_valid_upto_date" name="permit_valid_upto_date" value="<?php echo e(old('permit_valid_upto_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('permit_valid_upto_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Policy number <span class="required">*</span></label>
											<input type="text" class="form-control" id="policy_number" name="policy_number" value="<?php echo e(old('policy_number')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('policy_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Policy start date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="policy_start_date" name="policy_start_date" value="<?php echo e(old('policy_start_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('policy_start_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Policy end date <span class="required">*</span></label>
											<input type="text" class="form-control datetype" id="policy_end_date" name="policy_end_date" value="<?php echo e(old('policy_end_date')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('policy_end_date',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Renewal premium</label>
											<input type="text" class="form-control" id="renewal_premium" name="renewal_premium" value="<?php echo e(old('renewal_premium')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('renewal_premium',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Engine number</label>
											<input type="text" class="form-control" id="engine_number" name="engine_number" value="<?php echo e(old('engine_number')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('engine_number',':message')); ?>

		                  </small>
										</div>

										<div class="col-md-6 col-sm-6  form-group has-feedback">
											<label for="inputSuccess2">Chasis number</label>
											<input type="text" class="form-control" id="chasis_number" name="chasis_number" value="<?php echo e(old('chasis_number')); ?>" />
											<small class="text-danger">
		                    <?php echo e($errors->first('chasis_number',':message')); ?>

		                  </small>
										</div>

										<div class="ln_solid"></div>
											<div class="col-md-12 col-sm-12  offset-md-3">
												<button type="submit" class="btn btn-success">Submit</button>
											</div>

									</form>
							</div>

						</div>

					</div>
	</div>
</div>        
<?php $__env->stopSection(); ?>

<?php $__env->startPush('pagespecificjs'); ?>
<script>
$(document).ready(function(){
    $('#finance_type').on('change', function(){
    		var finance_type = $(this).val(); 
    		if(finance_type== 1)
    		{
    		$('#financecompany_id').val('');
        $("#financecompany_div").show();
      	}
      	else
      	{
				$('#financecompany_id').val('');
        $("#financecompany_div").hide();
      	}
    });

    var f_val = $( "#finance_type option:selected" ).val();
    		if(f_val== 1)
    		{
        $("#financecompany_div").show();
      	}
      	else
      	{
        $("#financecompany_div").hide();
      	}
});
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('layouts.adminapp', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\xampp\htdocs\insurance_project\resources\views/admin/vehicleDetails/savedetails.blade.php ENDPATH**/ ?>